package com.example.exp1postlab1_2_electricity

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
