import 'package:flutter/material.dart';

const products = [
  {
    'name': 'Headphones',
    'category': 'Electronics',
    'price': 1499,
    'icon': Icons.headphones,
    'description': 'Comfortable headphones with clear audio.',
  },
  {
    'name': 'Smart Watch',
    'category': 'Electronics',
    'price': 2499,
    'icon': Icons.watch,
    'description': 'A smart watch for everyday use.',
  },
  {
    'name': 'T-Shirt',
    'category': 'Fashion',
    'price': 599,
    'icon': Icons.checkroom,
    'description': 'A comfortable casual T-shirt.',
  },
  {
    'name': 'Backpack',
    'category': 'Accessories',
    'price': 999,
    'icon': Icons.backpack,
    'description': 'A useful backpack for college and travel.',
  },
];

class ProductListScreen extends StatelessWidget {
  const ProductListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const categories = ['All', 'Electronics', 'Fashion', 'Accessories'];

    return DefaultTabController(
      length: categories.length,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Products'),
          bottom: const TabBar(
            isScrollable: true,
            tabs: [
              Tab(text: 'All'),
              Tab(text: 'Electronics'),
              Tab(text: 'Fashion'),
              Tab(text: 'Accessories'),
            ],
          ),
        ),
        body: TabBarView(
          children: categories.map((category) {
            final items = category == 'All'
                ? products
                : products.where((p) => p['category'] == category).toList();

            return GridView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: items.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.8,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
              ),
              itemBuilder: (context, index) {
                final product = items[index];

                return GestureDetector(
                  onTap: () => Navigator.pushNamed(
                    context,
                    '/product-details',
                    arguments: product,
                  ),
                  onLongPress: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('${product['name']} selected')),
                    );
                  },
                  child: Card(
                    clipBehavior: Clip.antiAlias,
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            product['icon'] as IconData,
                            size: 54,
                            color: Colors.deepPurple,
                          ),
                          const SizedBox(height: 14),
                          Text(
                            product['name'] as String,
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 6),
                          Text('₹${product['price']}'),
                          Text(
                            product['category'] as String,
                            style: const TextStyle(color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          }).toList(),
        ),
      ),
    );
  }
}

class ProductDetailsScreen extends StatelessWidget {
  final Map<String, dynamic> product;

  const ProductDetailsScreen({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Product Details')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Center(
                child: Icon(
                  product['icon'] as IconData,
                  size: 120,
                  color: Colors.deepPurple,
                ),
              ),
            ),
            Text(
              product['name'] as String,
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(product['description'] as String),
            const SizedBox(height: 10),
            Text(
              '₹${product['price']}',
              style: const TextStyle(
                fontSize: 23,
                color: Colors.deepPurple,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: () =>
                  Navigator.pushNamed(context, '/cart', arguments: product),
              child: const SizedBox(
                width: double.infinity,
                child: Center(child: Text('Add to Cart')),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(radius: 48, child: Icon(Icons.person, size: 55)),
            SizedBox(height: 16),
            Text(
              'ShopEase User',
              style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
            ),
            Text('user@example.com'),
          ],
        ),
      ),
    );
  }
}

const foodCategories = [
  {'name': 'Pizza', 'icon': Icons.local_pizza},
  {'name': 'Burger', 'icon': Icons.lunch_dining},
  {'name': 'Sandwich', 'icon': Icons.bakery_dining},
];

const foods = [
  {
    'name': 'Cheese Pizza',
    'category': 'Pizza',
    'restaurant': 'Italian Corner',
    'price': 199,
    'icon': Icons.local_pizza,
    'description': 'Pizza topped with cheese and herbs.',
  },
  {
    'name': 'Veg Burger',
    'category': 'Burger',
    'restaurant': 'Burger House',
    'price': 129,
    'icon': Icons.lunch_dining,
    'description': 'A tasty burger with fresh vegetables.',
  },
  {
    'name': 'Veg Sandwich',
    'category': 'Sandwich',
    'restaurant': 'Fresh Bites',
    'price': 99,
    'icon': Icons.bakery_dining,
    'description': 'A freshly prepared vegetable sandwich.',
  },
];

class CategoryScreen extends StatelessWidget {
  const CategoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Food Categories')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: foodCategories.map((category) {
          return Card(
            child: ListTile(
              leading: Icon(
                category['icon'] as IconData,
                color: Colors.deepPurple,
              ),
              title: Text(category['name'] as String),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () => Navigator.pushNamed(
                context,
                '/restaurants',
                arguments: category['name'],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class RestaurantScreen extends StatelessWidget {
  final String category;

  const RestaurantScreen({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    final items = foods.where((f) => f['category'] == category).toList();

    return Scaffold(
      appBar: AppBar(title: Text('$category Restaurants')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: items.map((food) {
          return Card(
            child: ListTile(
              leading: Icon(food['icon'] as IconData, color: Colors.deepPurple),
              title: Text(food['restaurant'] as String),
              subtitle: Text('${food['name']} · ₹${food['price']}'),
              onTap: () => Navigator.pushNamed(
                context,
                '/food-details',
                arguments: food,
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class FoodDetailsScreen extends StatelessWidget {
  final Map<String, dynamic> food;

  const FoodDetailsScreen({super.key, required this.food});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Food Details')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Center(
                child: Icon(
                  food['icon'] as IconData,
                  size: 110,
                  color: Colors.deepOrange,
                ),
              ),
            ),
            Text(
              food['name'] as String,
              style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
            ),
            Text(food['restaurant'] as String),
            const SizedBox(height: 12),
            Text(food['description'] as String),
            const SizedBox(height: 12),
            Text(
              '₹${food['price']}',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: () =>
                  Navigator.pushNamed(context, '/cart', arguments: food),
              child: const SizedBox(
                width: double.infinity,
                child: Center(child: Text('Add to Cart')),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CartScreen extends StatelessWidget {
  final Map<String, dynamic>? item;

  const CartScreen({super.key, this.item});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cart')),
      body: item == null
          ? const Center(child: Text('Your cart is empty'))
          : Center(
              child: Card(
                margin: const EdgeInsets.all(20),
                child: ListTile(
                  leading: Icon(
                    item!['icon'] is IconData
                        ? item!['icon'] as IconData
                        : Icons.shopping_bag,
                  ),
                  title: Text(item!['name'] as String),
                  subtitle: Text('Price: ₹${item!['price']}'),
                ),
              ),
            ),
    );
  }
}
