import 'package:flutter/material.dart';

const students = [
  {'name': 'Rahul Sharma', 'id': 'MU001', 'course': 'Information Technology'},
  {'name': 'Priya Patel', 'id': 'MU002', 'course': 'Computer Engineering'},
  {'name': 'Amit Shah', 'id': 'MU003', 'course': 'Information Technology'},
];

class StudentListScreen extends StatelessWidget {
  const StudentListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Student List')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: students.length,
        itemBuilder: (context, index) {
          final student = students[index];

          return Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.person)),
              title: Text(student['name']!),
              subtitle: Text(student['id']!),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.pushNamed(
                context,
                '/student-details',
                arguments: student,
              ),
            ),
          );
        },
      ),
    );
  }
}

class StudentDetailsScreen extends StatelessWidget {
  final Map<String, dynamic> student;

  const StudentDetailsScreen({super.key, required this.student});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Student Details')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const CircleAvatar(radius: 45, child: Icon(Icons.person, size: 50)),
            const SizedBox(height: 20),
            Text(
              student['name'] as String,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.badge),
              title: const Text('Student ID'),
              subtitle: Text(student['id'] as String),
            ),
            ListTile(
              leading: const Icon(Icons.school),
              title: const Text('Course'),
              subtitle: Text(student['course'] as String),
            ),
          ],
        ),
      ),
    );
  }
}
