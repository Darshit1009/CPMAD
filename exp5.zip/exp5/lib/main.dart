import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/shopping_screens.dart';
import 'screens/student_screens.dart';
import 'screens/settings_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Shopping App',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => const HomeScreen());
          case '/products':
            return MaterialPageRoute(builder: (_) => const ProductListScreen());
          case '/product-details':
            return MaterialPageRoute(
              builder: (_) => ProductDetailsScreen(
                product: settings.arguments as Map<String, dynamic>,
              ),
            );
          case '/profile':
            return MaterialPageRoute(builder: (_) => const ProfileScreen());
          case '/students':
            return MaterialPageRoute(builder: (_) => const StudentListScreen());
          case '/student-details':
            return MaterialPageRoute(
              builder: (_) => StudentDetailsScreen(
                student: settings.arguments as Map<String, dynamic>,
              ),
            );
          case '/settings':
            return MaterialPageRoute(builder: (_) => const SettingsScreen());
          case '/categories':
            return MaterialPageRoute(builder: (_) => const CategoryScreen());
          case '/restaurants':
            return MaterialPageRoute(
              builder: (_) =>
                  RestaurantScreen(category: settings.arguments as String),
            );
          case '/food-details':
            return MaterialPageRoute(
              builder: (_) => FoodDetailsScreen(
                food: settings.arguments as Map<String, dynamic>,
              ),
            );
          case '/cart':
            return MaterialPageRoute(
              builder: (_) =>
                  CartScreen(item: settings.arguments as Map<String, dynamic>?),
            );
          default:
            return MaterialPageRoute(builder: (_) => const HomeScreen());
        }
      },
    );
  }
}
