package com.example.exp1_student_result

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
